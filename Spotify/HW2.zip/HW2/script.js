let fetchMusic = (query, id) => {
    let section = document.querySelector(`#${id}`)
    let row = section.querySelector(`#${id}Section`);
    console.log (section)

    fetch("https://striveschool-api.herokuapp.com/api/deezer/search?q="+query)
    .then ((raw) => raw.json())
    .then ((res)=> {
        let results = res.data;        
        console.log(results);
        section.classList.remove("d-none");

        for (let i=0; i<results.slice(0,5).length; i++){
            let element = results[i]
            row.innerHTML += `
            <div class="card maxClass">
  <img src="${element.album.cover_xl}" class="card-img-top img-fluid" alt="cover">
  <div class="card-body">
    <h5 class="card-title">${element.album.title}</h5>
    <button type="button" onclick="modal(ArtistID)" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#maxModal">
  More Info
</button>
  </div>
  <div class="card-body d-flex justify-content-around">
    <a target= "_blank" href="${element.preview}" class="card-link">Preview</a>
    <a href="${element.link}" class="card-link">Track Link</a>
  </div>
</div>
            `
        
        } return [results, section]




    })
    .catch ((err)=>console.log(err))




}
fetchMusic("eminem", "eminem")
fetchMusic("metallica", "metallica")
fetchMusic("queen", "queen")




//FUNZIONE MODAL


function modal(ArtistId){

  fetch("https://striveschool-api.herokuapp.com/api/deezer/search?q="+ArtistId)
    .then ((response) => response.json())
    .then ((res) => {
      let modRes = res.data;
      console.log(modRes)
      // let nameModRes = modRes.artist
      // console.log(nameModRes)
      for (let i=0; i<modRes.length; i++){
        let modaldatas = modRes[i];
        let modalBody = document.getElementById("listModal");
        let modalTitle = document.getElementById("modalTitle");

        modalTitle.innerHTML = `
          <h1>${modaldatas.artist.name}</h1>
        `

      modalBody.innerHTML =`
      <div class="col-md-6 d-flex">
        <img src="${modaldatas.album.cover_medium}"
      </div>
      <div class="col-md-6" d-flex>
         <ul class="list-group-flush" >
 <li class="list-group-item">${modaldatas.title}</li>
 <li class="list-group-item">${modaldatas.album.title}</li>
 <li class="list-group-item">${modaldatas.duration}</li>
  </ul>
           </div> 
         `

        }
 
    }
    )
       
}

modal("eminem");
modal("metallica");
modal("queen");












// let sec = section
// console.log(sec)


  //   let search = () => {
  //     let input = document.getElementById("searchField");
  //   let inputVal = input.value;
  //     for (let i=0; i<sec.length; i++){
  //       let secFiltered = sec[i];

  //  if (inputVal.toLowerCase() != secFiltered.id){
  // secFiltered.classList.add("d-none")
  //   console.log(input.value)
  // }
  // console.log(input.value)
  // console.log(section)
// }
// }

// }
//Funzione per vedere le info 

// function showModal (modalBoot) {
//   let details = 
  //          function showDetail(section){
  //           let names = element.artist.name.find(artist=>artist.name===section)
            
  //           let modalBody = document.getElementById("listModal");

  //           modalBody.innerHTML = `
  //           <ul class="list-group list-group-flush">
  //   <li class="list-group-item">${element.title}</li>
  //   <li class="list-group-item">${element.album.title}</li>
  //   <li class="list-group-item">${element.duration}</li>
  // </ul>
            
  //           `

  //         }

  //       function showModalDetail(nomeID){
          
  //         let name = results.artist.find(element=>element.artist.name===nomeID);
  //         
  //         let modalImg = document.getElementById("imgCoverM");
  //         let listModal = document.getElementById("listModal");
  //         modalTitle.textContent = element.artist.name;
  //         listModal.innerHTML = `
  //           <div class="col-md-12" id="imgCoverM">
  //             <img src="${element.album.cover_medium}" alt"${element.title}>
  //           </div>
          
  //          <ul class="list-group list-group-flush">
  //   <li class="list-group-item">${element.title}</li>
  //   <li class="list-group-item">${element.album.title}</li>
  //   <li class="list-group-item">${element.duration}</li>
  // </ul>
  //       </div>
  //         `
  //       new boostrap.Modal(document.getElementById("maxModal")).show()   
  //       }
            
            
            // modalArtName.innerHTML += `
            // <h1>
            // ${element.artist.name[i]}
            // </h1>
            // `;
            // modalImg.innerHTML += `
            //   <img src="${element.album.cover_medium}" class="card-img-top img-fluid" alt="cover">

            // `
// }
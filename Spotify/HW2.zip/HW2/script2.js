let mButton = document.getElementById("button-search");
let input = document.getElementById("searchField");
function search(){
let inputVal = input.value.toLowerCase();

input.value = " "
 let searchSection = document.getElementById("searchSection")
 
let found = document.getElementById("found")
    fetch(`https://striveschool-api.herokuapp.com/api/deezer/search?q=${inputVal}`)
    .then((response)=>response.json())
    .then((data)=>{
      let res = data.data
      console.log (res)
    found.classList.remove("d-none");
      
      for (let i=0; i<res.slice(0,5).length; i++){
        
        let element = res[i]
        
        searchSection.innerHTML += `
        <div class="card maxClass">
  <img src="${element.album.cover_xl}" class="card-img-top img-fluid" alt="cover">
  <div class="card-body">
    <h5 class="card-title">${element.album.title}</h5>
    <button type="button" onclick="modal(ArtistID)" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#maxModal">
  More Info
</button>
  </div>
  <div class="card-body d-flex justify-content-around">
    <a target= "_blank" href="${element.preview}" class="card-link">Preview</a>
    <a href="${element.link}" class="card-link">Track Link</a>
  </div>
</div>
`

      }return [data, inputVal]
      
    })
  .catch((error)=>{
    console.log(error);
  })
   
    
  } 

 mButton.addEventListener("click", function() {
    let searchSection = document.getElementById("searchSection")
    searchSection.innerHTML = ""
        function reset (id){
            let resetBaseCard = document.getElementById(id)
            resetBaseCard.classList.add("d-none")
        }
        reset("eminem")
        reset("queen")
        reset("metallica")

    })
